# Sager Task 

A simple Server that use socket.io to send the geo-location of the drone . 

### Stack overflow question:


Happy Coding : 
```
npm install
npm start
```


